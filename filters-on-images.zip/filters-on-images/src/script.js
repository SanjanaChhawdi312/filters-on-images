var ifile;
var iimage = null;
var oimage = null;
var iCanvas = document.getElementById("ican");
var oCanvas = document.getElementById("ocan");
var context1 = iCanvas.getContext("2d");

//-----------------load -----------------------
function loadImage() {
  ifile = document.getElementById("ifile");
  iimage= new SimpleImage(ifile);
  iimage1 = new Image();
  iimage1.onload = function() {
    iCanvas.width = iimage1.width;
    iCanvas.height = iimage1.height;
    oCanvas.width = iimage1.width;
    oCanvas.height = iimage1.height;
    context1.drawImage(iimage1, 0, 0);
    var context2 = oCanvas.getContext("2d");
    context2.drawImage(iimage1, 0, 0);
  };
  iimage1.src = URL.createObjectURL(ifile.files[0]);
}
//------------resize image-------------------
function isNumeric(value) {
  return !isNaN(value);
}

function setWidth(value) {
  if (isNumeric(value)) {
    context1.save();
    iCanvas.width = value;
    oCanvas.width = value;
    context1.drawImage(iimage1, 0, 0, iCanvas.width, iCanvas.height);
    var context2 = oCanvas.getContext("2d");
    context2.drawImage(iimage1, 0, 0, oCanvas.width, oCanvas.height);
    context1.restore();
  }
}

function setHeight(value) {
  if (isNumeric(value)) {
    context1.save();
    iCanvas.height = value;
    oCanvas.height = value;
    context1.drawImage(iimage1, 0, 0, iCanvas.width, iCanvas.height);
    var context2 = oCanvas.getContext("2d");
    context2.drawImage(iimage1, 0, 0, oCanvas.width, oCanvas.height);
    context1.restore();
  }
}

//--------------------Gray----------------
function changeGray() {
  if (iimage == null || !iimage.complete) {
    alert("Image not loaded");
  }
  var finalImage = createCompositeGray();
  finalImage.drawTo(oCanvas);
}

function createCompositeGray() {
  var output = new SimpleImage(iimage.width, iimage.height);
  for (var pix of iimage.values()) {
    var avg = (pix.getRed() + pix.getBlue() + pix.getGreen()) / 3;
    pix.setGreen(avg);
    pix.setBlue(avg);
    pix.setRed(avg);
    var x = pix.getX();
    var y = pix.getY();
    var pixel = iimage.getPixel(x, y);
    output.setPixel(x, y, pixel);
  }
  return output;
}

//------------------RAINBOW-------------
//function to call composite rainbow function
function changeRainbow() {
  if (iimage == null  || ! iimage.complete){
    alert("Image not loaded");
  }
  var finalImage = createCompositeRainbow();
  finalImage.drawTo(oCanvas);
}
//function to compose rainbow color
function createCompositeRainbow() {
  var output=new 
SimpleImage(iimage.getWidth(),iimage.getHeight());
  var h=iimage.getHeight();
  for(var pix of iimage.values()) {
    if(pix.getY()<1/7*h)
    {
      pix.setRed(148);
      pix.setBlue(211);
    }
    if((pix.getY()>=1/7*h)&&(pix.getY()<2/7*h))
    {
       pix.setRed(75);
       pix.setBlue(130);
    }
    if((pix.getY()>=2/7*h)&&(pix.getY()<3/7*h))
    {
        pix.setBlue(255);  
    }
    if((pix.getY()>=3/7*h)&&(pix.getY()<4/7*h))
    {
        pix.setGreen(255);
    }
    if((pix.getY()>=4/7*h)&&(pix.getY()<5/7*h))
    {
        pix.setRed(255);
        pix.setGreen(255);
    }
    if((pix.getY()>=5/7*h)&&(pix.getY()<6/7*h))
    {
        pix.setRed(255);
        pix.setGreen(127);
    }
    if((pix.getY()>=6/7*h)&&(pix.getY()<=h))
    {
        pix.setRed(255);
    }
    var x=pix.getX();
    var y=pix.getY();
    oCanvas=document.getElementById("ocan");
    var pixel = iimage.getPixel(x,y);
    output.setPixel(x,y,pixel);
  }
return output;
}

//------------------BLUR----------------
//function to call composite blur
function changeBlur() {
  if (iimage == null  || ! iimage.complete ){
    alert("Image not loaded");
  }
  var finalImage = createCompositeBlur();
  finalImage.drawTo(oCanvas);
}
//function to compose blur output
function createCompositeBlur() {
var output=new SimpleImage(iimage.getWidth(),iimage.getHeight());
var randomInt = (Math.random()*10)-10;
for(var pix of iimage.values()) {
  if(Math.random() < 0.5){
    var otherX=pix.getX() + randomInt;
    var otherY=pix.getY() + randomInt;
    if (otherX < 0) {
        otherX = pix.getX();
    }
    if (otherY < 0) {
        otherY = pix.getY();
     }
     if (otherX > output.getWidth() - 1) {
         otherY = output.getWidth() - 1;
     }
     if (otherY > output.getHeight() - 1){
        otherY = output.getHeight() - 1; 
     }
  }
  oCanvas=document.getElementById("ocan");
  output.setPixel( pix.getX(), pix.getY(), iimage.getPixel(otherX, otherY));
  }
  return output;
}
//------------------RED-----------------
//function to call composite red function
function changeRed() {
  //check that images are loaded
  if (iimage == null  || ! iimage.complete) {
    alert("Image not loaded");
  }
  var finalImage = createCompositeRed();
  finalImage.drawTo(oCanvas);
}
//function to compose red color
function createCompositeRed() {
  var output=new SimpleImage(iimage.getWidth(),iimage.getHeight());
  for(var pix of iimage.values()) {
    pix.setRed(255);
    var x=pix.getX();
    var y=pix.getY();
    oCanvas=document.getElementById("ocan");
    var pixel = iimage.getPixel(x,y);
    output.setPixel(x,y,pixel);
    }
  return output;
}
//-----------------------HUE----------------
//function to call composite hue
function changeHue() {
  //check that images are loaded
  if (iimage == null  || ! iimage.complete) {
    alert("Image not loaded");
  }
  var finalImage = createCompositeHue();
  finalImage.drawTo(oCanvas);
}
function createCompositeHue() {
  //composing gray screen
  var output=new SimpleImage(iimage.getWidth(),iimage.getHeight());
  for(var pix of iimage.values()) {
      var avg=((pix.getRed())+(pix.getBlue())+(pix.getGreen()))/3;
    if(avg<128)
    {
      pix.setGreen(2*avg);
      pix.setBlue(0);
      pix.setRed(0);
    }
    else
    {
      pix.setGreen(255);
      pix.setBlue((2*avg)-255);
      pix.setRed((2*avg)-255);
    }
    var x=pix.getX();
    var y=pix.getY();
    oCanvas=document.getElementById("ocan");
    var pixel = iimage.getPixel(x,y);
    output.setPixel(x,y,pixel);
    }
  return output;
}
//-----------------CREATOR'S CHOICE-----------
//function to call creator choice program
function change() {
  if (iimage == null || ! iimage.complete) {
    alert("Image not loaded");
  }
  var finalImage=createComposite();
  finalImage.drawTo(oCanvas);
}
//function to compose creator choice output
function createComposite() {
  var output=new SimpleImage(iimage.getWidth(),iimage.getHeight());
oCanvas=document.getElementById("ocan");
var context = oCanvas.getContext("2d"); 
  context.beginPath();
  context.rect(20,20,480,480);
  context.stroke();
  for(var pix of iimage.values()) {
    if(pix.getX()<=20||pix.getX()>=iimage.getWidth()-20){
      pix.setGreen(0);
      pix.setRed(0);
      pix.setBlue(0);
    }
    else if(pix.getY()<=20||pix.getY()>=iimage.getHeight()-20){
      pix.setGreen(0);
      pix.setRed(0);
      pix.setBlue(0);
    }
    var x=pix.getX();
    var y=pix.getY();
    var pixel = iimage.getPixel(x,y);
    output.setPixel(x,y,pixel);
  }
  return output;
}

//----------------reset image----------------
function reset() {
  var ifile=document.getElementById("ifile");
  iimage=new SimpleImage(ifile);
  oimage=new SimpleImage(ifile);
  iimage.drawTo(iCanvas);
  oimage.drawTo(oCanvas);
}
//---------------Clear image------------------
function clearCanvas() {
  doClear(iCanvas);
  doClear(oCanvas);
}

function doClear(canvas) {
  var context = canvas.getContext("2d");
  context.clearRect(0,0,canvas.width,canvas.height);
  return;
} 